package com.example.miniproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class success extends AppCompatActivity {
    TextView text1,timerText;
    Button start,end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        text1 = findViewById(R.id.textView2);
        start = findViewById(R.id.button);
        end = findViewById(R.id.button2);
        timerText=findViewById(R.id.timerText);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ExampleAsynchTask task = new ExampleAsynchTask();
                task.execute();
            }
        });
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    text1.clearAnimation();
                    text1.setSelected(false);
                    text1.setVisibility(View.INVISIBLE);
                    timerText.setText("00:00:00");
                    timerText.setVisibility(View.INVISIBLE);
                } catch (Exception e){
                    e.printStackTrace();
                }
            }

        });
    }
    public class ExampleAsynchTask extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... strings) {
            try{
                Thread.sleep(250);
            } catch (InterruptedException e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(success.this, "Thread Started", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            text1.setVisibility(View.VISIBLE);
            timerText.setVisibility(View.VISIBLE);
            text1.startAnimation(AnimationUtils.loadAnimation(getBaseContext(), R.anim.move_left_right));
            new CountDownTimer(5000, 1000) {

                public void onTick(long millisUntilFinished) {
                    // Used for formatting digit to be in 2 digits only
                    NumberFormat f = new DecimalFormat("00");
                    long hour = (millisUntilFinished / 3600000) % 24;
                    long min = (millisUntilFinished / 60000) % 60;
                    long sec = (millisUntilFinished / 1000) % 60;
                    timerText.setText(f.format(hour) + ":" + f.format(min) + ":" + f.format(sec));
                }
                // When the task is over it will print 00:00:00 there
                public void onFinish() {
                    timerText.setText("Text moved from left to right");
                }
            }.start();
        }
    }
}
