package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.s1);
        e2=findViewById(R.id.s2);
    }

    public void signup(View v) {
        String n = e1.getText().toString();
        String p = e2.getText().toString();
        if (!isValidPassword(p)) {
            Toast.makeText(this, "password doesn't match rule", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this,login.class);
        intent.putExtra("email",n);
        intent.putExtra("password",p);
        startActivity(intent);
    }

    Pattern lowercase=Pattern.compile("^.*[a-z].*$");
    Pattern uppercase=Pattern.compile("^.*[A-Z].*$");
    Pattern number=Pattern.compile("^.*[0-9].*$");
    Pattern specialCharacter=Pattern.compile("^.*[^a-zA-Z0-9].*$");

    private Boolean isValidPassword(String password) {

        if(password.length()<8) {
            return false;
        }

        if(!lowercase.matcher(password).matches()) {
            return false;
        }
        if(!uppercase.matcher(password).matches()) {
            return false;
        }
        if(!number.matcher(password).matches()) {
            return false;
        }
        if(!specialCharacter.matcher(password).matches()) {
            return false;
        }
        return true;
    }
}