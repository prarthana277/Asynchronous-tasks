package com.example.miniproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText e1,e2;
    String n,p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1=findViewById(R.id.l1);
        e2=findViewById(R.id.l2);
        n=getIntent().getStringExtra("email");
        p=getIntent().getStringExtra("password");
    }

    public void login(View v) {
        String ln = e1.getText().toString();
        String lp = e2.getText().toString();
        if(ln.equals(n) && lp.equals(p))
        {
            Intent i1=new Intent(this,success.class);
            startActivity(i1);
        }
        else{
            Toast.makeText(this,"username and password doesn't match",Toast.LENGTH_SHORT).show();
        }

    }
}